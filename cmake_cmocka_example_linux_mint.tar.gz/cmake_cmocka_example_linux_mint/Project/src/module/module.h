#ifndef MODULE_H
#define MODULE_H

// Function declarations or other definitions can go here
void module_func1(void);

#endif // MODULE_H