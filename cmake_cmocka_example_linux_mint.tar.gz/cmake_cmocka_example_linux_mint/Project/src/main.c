#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "module.h"


int main(void)
{
    module_func1();
    printf("Hello World\n");
    return 0;
}